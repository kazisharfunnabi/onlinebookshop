<?php 

ob_start(); ?>
 <!DOCTYPE html>
<html>
<head>
 
    <style>
	
		
	table {

  	width: 100%;
	}

	th, td {
  	text-align:inherit;
  	padding: 10px;
	}

	.user-info p{
		   font-size: 25px;
		   color: black;
	   }
		
/*
		.container-fluid{
			background: white;
		}
		
*/

</style>
</head>
<body>
 
   <div class="container-fluid">
	<div class="row">
	<div class="col-md-2"></div>
	<div class="col-md-10">
  	<form action="" method="post"> 
   	<table class="table table-hover">
       
<!--
       <div id="bulkOptionsContainerfuel" class="col-xs-4" style="padding: 0px;">
            <select name="bulkoption" id="" class="form-control" >
                <option value="">Select Options</option>
                <option value="draft">Draft</option>
                <option value="published">Publish</option>
                <option value="delete">Delete</option>
            </select>
       </div>
       <div class="col-xs-4">

           <input type="submit" name="submit" value="Apply" class="btn btn-success">
           <a href="fuels.php?source=add_fuel" class="btn btn-primary">Add New Fuel</a>
       </div>
-->
        <thead>
            <tr>
                
                <th>ID</th>
                <th>Book Name</th>
                <th>Image</th>
                <th>Author</th>
                <th>Category</th>
                <th>Price</th>
                <th>Description</th>
                <th>Edit</th>
                <th>Delete</th>
         
            </tr>
        </thead>
        <tbody>                                    
<?php
                               
    $query= "SELECT * FROM book_info";
    $view_all_charity= mysqli_query($connection,$query);
    
    while($row=mysqli_fetch_assoc($view_all_charity)){
		
        
			$book_id=$row['book_id'];
	        $name=$row['name'];
	        $author=$row['author'];
            $price=$row['price'];
            $cat_title=$row['cat_title'];
            $image=$row['image'];
            $description=$row['description'];
        ?>
        
        
        <?php
		echo "<tr>";	
        echo "<td>$book_id</td>";
        echo "<td>$name</td>";
        echo "<td><img src='../assets/img/$image' width=200></td>"; 
        echo "<td>$author</td>";
        echo "<td>$cat_title</td>";
		echo "<td>$price</td>";
		echo "<td>$description</td>";
        echo "<td><a href='books.php?source=edit_books&book_id={$book_id}'>Edit</a></td>";
        echo "<td><a href='books.php?delete={$book_id}'>Delete</a></td>";
        
        echo "</tr>";
    }
			if(isset($_GET['delete'])){
			$Delete_charity_Id=$_GET['delete'];
			$deleting_charity_query="DELETE FROM book_info WHERE book_id='$Delete_charity_Id'";
			$deleting_charity_table=mysqli_query($connection,$deleting_charity_query);
			if($deleting_charity_table){
				header ("Location:books.php");
					}
			}

			?>                        
        </tbody>
    </table>
</form>
</div>
</div>
</div>
</body>
</html>