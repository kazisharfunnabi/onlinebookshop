<?php include "../includes/db.php"?>
<?php
if(isset($_POST['submit'])){
    
    $user_firstname=$_POST['user_firstname'];
    $user_lastname=$_POST['user_lastname'];
    $user_role=$_POST['user_role'];
    $username=$_POST['username'];     
    $user_email=$_POST['user_email'];
    $user_password=$_POST['user_password'];
	
    $query= "INSERT INTO user(user_firstname, user_lastname, user_role, username, user_email, user_password) VALUES ( '{$user_firstname}', '{$user_lastname}',  '{$user_role}', '{$username}', '{$user_email}', '{$user_password}')";
    
    $create_user_query= mysqli_query($connection,$query);
    
    if(!$create_user_query){
            die("Query Failed". mysqli_error($connection));
        }
}
?>


<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Book Store</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="colorlib.com">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.css">

		<!-- DATE-PICKER -->
		<link rel="stylesheet" href="vendor/date-picker/css/datepicker.min.css">

		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style.css">
	</head>
	<body>
		<div class="wrapper">
            <form action="" id="wizard" method="post">
        		<!-- SECTION 1 -->
                <h4></h4>
                <section>
                    <div class="inner">
                    	<a href="#" class="avartar">
                    		<img src="images/pexels-pixabay-301920.jpg" alt="">
                    	</a>
                    	<div class="form-row form-group">
                    		<div class="form-holder">
                    			<input type="text" class="form-control" name="user_firstname" placeholder="First Name">
                    		</div>
                    		<div class="form-holder">
                    			<input type="text" class="form-control" name="user_lastname" placeholder="Last Name">
                    		</div>
                    	</div>
                    	<div class="form-row">
                    		<div class="form-holder">
                    			<input type="text" class="form-control" name="username" placeholder="Username">
                    		</div>
                    	</div>
                    	<div class="form-row">
                    		<div class="form-holder">
                    			<input type="password" class="form-control" name="user_password" placeholder="Password">
                    			<i class="zmdi zmdi-lock-open small"></i>
                    		</div>
                    	</div>
                    	<div class="form-row">
                    		<select name="user_role" id="" class="form-control">
							<option value="" disabled selected>User Type</option>
							<option  value="Admin">Admin</option>
							<option  value="User">User</option>
						</select>
                    	</div>
                    	<div class="form-row">
                    		<div class="form-holder">
                    			<input type="text" class="form-control" name="user_email" placeholder="Email">
                    			<i class="zmdi zmdi-email small"></i>
                    		</div>
                    	</div>
                    	<button type="submit" name="submit">Register
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
                    </div>
                </section>
            </form>
		</div>

	
		
		<!-- JQUERY STEP -->
		<script src="js/jquery.steps.js"></script>

		<!-- DATE-PICKER -->
		<script src="vendor/date-picker/js/datepicker.js"></script>
		<script src="vendor/date-picker/js/datepicker.en.js"></script>

		<script src="js/main.js"></script>

<!-- Template created and distributed by Colorlib -->
</body>
</html>