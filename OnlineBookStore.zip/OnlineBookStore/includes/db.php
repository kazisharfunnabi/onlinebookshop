<?php

$connection=mysqli_connect ('localhost','root','','onlinebookshop');
//if(!$connection){
//	echo "we are not";	
//} else{
//	echo "we are in";
//}


?>