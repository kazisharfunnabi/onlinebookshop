-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 05:05 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinebookshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_info`
--

CREATE TABLE `book_info` (
  `book_id` int(11) NOT NULL,
  `cat_title` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `price` int(100) NOT NULL,
  `description` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_info`
--

INSERT INTO `book_info` (`book_id`, `cat_title`, `name`, `author`, `price`, `description`, `image`) VALUES
(7, 'Magical', 'Majka', 'George Eliot', 300, 'A book is a proof that humans are capable of magic said Carl Sagan, an astronomer famously known for dumbing down the mysteries of the cosmos for mere mortals.', 'pexels-ena-marinkovic-3713699.jpg'),
(8, 'Adventure', 'Northern Winds', 'Rupi Kaur', 300, 'Adventure stories are a genre that involve protagonists going on epic journeys. These journeys are most often geographical but may also include emotional and personal journeys and growth. The adventure, the goal of the quest at hand, must take center stage in an adventure story.', 'pexels-arthouse-studio-4354390.jpg'),
(9, 'Romance', 'The Passion', 'Rupi Kaur', 200, 'A romance novel or romantic novel is a genre fiction novel that primary focuses on the relationship and romantic love between two people, typically with an emotionally satisfying and optimistic ending.', 'pexels-pixabay-256450.jpg'),
(10, 'Romance', 'The Fault In Our Stars', 'John Green', 200, 'A romance novel or romantic novel is a genre fiction novel that primary focuses on the relationship and romantic love between two people, typically with an emotionally satisfying and optimistic ending.', 'yosuke-ota-OlvgW1LhghQ-unsplash.jpg'),
(11, 'Adventure', 'Love Boat', 'Abile Hing', 250, 'Feel the power of strength and banding together come alive through the celebration of our very own female animal characters in Lili the Lioness & Friends. Written, designed and produced in-house, this impactful read highlights the importance of community', 'jkkj.jpg'),
(12, 'Adventure', 'Stephen King', 'Carre', 150, 'The political struggle in the ancient city of Hastinapur is escalating as the Pandavas and Kauravas are on the verge of war. But its the rise of the demonic Asura King, Mahendrasura, that most troubles Krishna.', 'FGGH.jpg'),
(13, 'Adventure', 'Batman Knight', 'DC', 300, 'The political struggle in the ancient city of Hastinapur is escalating as the Pandavas and Kauravas are on the verge of war. But its the rise of the demonic Asura King, Mahendrasura, that most troubles Krishna.', 'kjkjl.jpg'),
(15, 'Magical', 'Seventh Sun', 'Lani Forbes', 250, 'The terrible Asuras are pretty notorious. These demons have decided to spread chaos across the world and win over heaven. Here comes an Asura trying to kidnap mother Earth', 'kjljl.jpg'),
(16, 'Knowledge', 'Darwin', ' Darwin D.', 200, 'This complete guide will cover everything you need to know about writing Knowledge Base Articles for business', 'sddxc.jpg'),
(17, 'Horror', 'Last Blood', 'ALEXENDER GREGG', 150, ' Horror is a genre of literature, film, and television that is meant to scare, startle, shock, and even repulse audiences.', 'hjhj.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` text NOT NULL,
  `quantity` int(50) NOT NULL,
  `total` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `book_id`, `user_id`, `name`, `price`, `image`, `quantity`, `total`) VALUES
(34, 10, 2, 'The Fault In Our Stars', 200, 'yosuke-ota-OlvgW1LhghQ-unsplash.jpg', 1, 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `confirm_order`
--

CREATE TABLE `confirm_order` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `total_books` varchar(100) NOT NULL,
  `pay_method` varchar(200) NOT NULL,
  `total_price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `confirm_order`
--

INSERT INTO `confirm_order` (`order_id`, `user_id`, `name`, `email`, `number`, `address`, `total_books`, `pay_method`, `total_price`) VALUES
(10, 9, 'Tahasin Elias', 'tahasinmim31@gmail.com', 1874524796, 'Mohora, Kalurghat', 'The Fault In Our Stars #10,(1)  Northern Winds #8,(1)  The Passion #9,(1)  Stephen King #12,(1)  Nor', 'cash on delivery', 1350.00),
(11, 8, 'Mr.Jon', 'jon@gmail.com', 1882020232, 'Lalkhan, Chittagong', 'Darwin #16,(2)  The Passion #9,(1)  Batman Knight #13,(1) ', 'cash on delivery', 900.00),
(12, 10, 'Rehena Begum', 'rehena@gmail.com', 1874524796, 'New Market, Chittagong', 'Darwin #16,(2)  Stephen King #12,(1) ', 'cash on delivery', 550.00),
(13, 8, 'Karim Ahmed', 'user@gmail.com', 1882020232, 'Mohora, Kalurghat', 'Batman Knight #13,(2) ', 'cash on delivery', 600.00),
(14, 11, 'farhana farha', 'farhana123@gmail.com', 1882020232, 'Khulshi,Chitagong', 'Darwin #16,(2)  Majka #7,(1) ', 'cash on delivery', 600.00);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `msg_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `msg` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`msg_id`, `user_id`, `username`, `user_email`, `msg`) VALUES
(3, 2, 'user', 'karim@gmail.com', 'gjkndgdfjgn'),
(4, 11, 'farhana', 'farhana123@gmail.com', 'Hi, Your system is really helpful.');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `user_firstname` varchar(50) NOT NULL,
  `user_lastname` varchar(50) NOT NULL,
  `user_role` varchar(50) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `user_firstname`, `user_lastname`, `user_role`, `user_password`, `user_email`) VALUES
(1, 'Admin', 'Md.', 'Elias', 'Admin', 'admin', 'admin@gmail.com'),
(2, 'user', 'Shah', 'Alam', 'User', '12345', 'karim@gmail.com'),
(4, 'admin', 'Karim', 'Niaz', 'Admin', '123', 'karim@gmail.com'),
(5, 'admin', 'Karim', 'Niaz', 'Admin', '123', 'karim@gmail.com'),
(6, 'admin', 'Karim', 'Niaz', 'Admin', '123', 'karim@gmail.com'),
(7, 'admin1', 'Tahasin', 'Elias', 'Admin', '222', 'tahasin31@gmail.com'),
(8, 'user1', 'Karim', 'Ahmed', 'User', '333', 'user@gmail.com'),
(9, 'user2', 'Shan', 'Chowdhury', 'User', '000', 'user2@gmail.com'),
(10, 'user4', 'Rehena', 'Begum', 'User', '888', 'rehena@gmail.com'),
(11, 'farhana', 'Farhana', 'Farha', 'User', '123', 'farhana123@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_info`
--
ALTER TABLE `book_info`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirm_order`
--
ALTER TABLE `confirm_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`msg_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_info`
--
ALTER TABLE `book_info`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `confirm_order`
--
ALTER TABLE `confirm_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
